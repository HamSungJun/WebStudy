insert into PC values (1001 ,133, 16, 1.6, '6x', 1595);
insert into PC values (1002 ,120, 16, 1.6, '6x', 1399);
insert into PC values (1003 ,166, 24, 2.5, '6x', 1899);
insert into PC values (1004 ,166, 32, 2.5, '8x', 1999);
insert into PC values (1005 ,166, 16, 2.0, '8x', 1999);
insert into PC values (1006 ,200, 32, 3.1, '8x', 2099);
insert into PC values (1007 ,200, 32, 3.2, '8x', 2349);
insert into PC values (1008 ,180, 32, 2.0, '8x', 3699);
insert into PC values (1009 ,200, 32, 2.5, '8x', 2599);
insert into PC values (1010 ,160, 16, 1.2, '8x', 1495);

