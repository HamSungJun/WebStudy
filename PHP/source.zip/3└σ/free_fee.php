﻿<?
  $age = 68;
  $fee = "2,000원";
       
  if ($age>=65)
  {
    $fee = "무료";
  }
  
  echo "나이 : $age 세, 지하철 요금 : $fee";
?>
