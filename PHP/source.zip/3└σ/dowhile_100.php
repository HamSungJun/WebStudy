﻿<?
   $i = 100;

   do 
   {
      echo $i."<br>";
   } while ($i <= 10)
?>
