﻿<?   
   	$sum=0;
   
   	for($a=1; $a<=10; $a++)
   	{
      	    $sum=$sum+$a;     
   	}
 
   	echo("1에서 10까지 자연수의 합은 $sum 입니다.<br>");
?>

