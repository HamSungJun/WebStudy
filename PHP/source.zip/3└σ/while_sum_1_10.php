﻿<?
   $a=1;
   $sum=0;
   
   while($a<=10)
   {
      $sum=$sum+$a;
      $a++;
   }
 
   echo("1에서 10까지 자연수의 합은 $sum 입니다.<br>");
?>

