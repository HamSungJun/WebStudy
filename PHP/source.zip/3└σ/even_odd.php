﻿<?
  $num = 80;

  if ($num%2==0)
  {
    echo "$num : 짝수";
   }
  else
  {
    echo "$num : 홀수";	
   }
?>
