﻿<?
	$besu = 5;               // 대상 숫자

	$num = 15;		// 5의 배수인지를 판별하고자 하는 대상 숫자

	if ($num % $besu == 0)
        {
	   echo "$num 은(는) $besu 의 배수다.";
        } 
	else
	{
	   echo "$num 은(는) $besu 의 배수가 아니다.";	    
	}
?>

