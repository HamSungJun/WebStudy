﻿<?
   $i = 100;

   while ($i <= 10)
   {
      echo $i."<br>";
   }
?>
