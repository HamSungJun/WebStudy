<div class="menus"><a href="../memo/memo.php"><img src="../img/menu01.gif" border="0"></a></div>
<div class="menus"><a href="../greet/list.php"><img src="../img/menu02.gif" border="0"></a></div>
<div class="menus"><a href="../concert/list.php"><img src="../img/menu03.gif" border="0"></a></div>
<div class="menus"><a href="../download/list.php"><img src="../img/menu04.gif" border="0"></a></div>
<div class="menus"><a href="../free/list.php"><img src="../img/menu05.gif" border="0"></a></div>
<div class="menus"><a href="../qna/list.php"><img src="../img/menu06.gif" border="0"></a></div>
<div class="menus"><a href="#"><img src="../img/menu07.gif" onclick="window.open('../survey/survey.php', '','scrollbars=no, toolbars=no,width=180,height=230')" border="0"></a></div>