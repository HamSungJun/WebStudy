create table survey(
   ans1 int,
   ans2 int,
   ans3 int,
   ans4 int
   );

insert into survey values(0, 0, 0, 0);
