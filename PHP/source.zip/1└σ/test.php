﻿<?
	phpinfo();
?>