﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>안녕~~~</title>
</head>
<body>
<?
    echo "<p>안녕하세요!</p>"
?>
</body>
</html> 