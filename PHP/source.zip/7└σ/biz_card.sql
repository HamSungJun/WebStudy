﻿create table biz_card (
	num int,
	name char(10),
	company char(30),
	tel char(20),
        hp char(20),
	address char(100),
	primary key(num)
);