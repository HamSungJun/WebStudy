﻿<?   
       function aaa() 
       {
             echo ("안녕하세요!");
       }

       aaa();
?>