﻿<?
        function plus($a, $b)
        {
                $c = $a + $b;
                echo $c;
        }

        plus(15, 25);
        echo "<br>";
        plus(3500, 1500);
?> 