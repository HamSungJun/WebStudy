﻿<?
        function plus($a, $b)
        {
                $c = $a + $b;

                return $c;
        }

        $result = plus(15, 25);
        echo $result."<br>";
   
        $result = plus(3500, 1500);
        echo $result;
?> 