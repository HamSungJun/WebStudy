﻿<?
   $a = "자동차";
   echo "<br>";     	// 줄바꿈
   echo $a;

   $a = "기차";
   echo "<br>"; 	// 줄바꿈
   echo $a;
 
   $a = 1000;
   echo "<br>";		// 줄바꿈
   echo $a;
?>
